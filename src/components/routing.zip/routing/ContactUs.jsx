import React from 'react'

const ContactUs = () => {
  return (
    <div>ContactUs Page</div>
  )
}

export default ContactUs