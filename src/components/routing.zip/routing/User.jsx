import React from 'react'

const User = () => {
  return (
    <div>User Page</div>
  )
}

export default User