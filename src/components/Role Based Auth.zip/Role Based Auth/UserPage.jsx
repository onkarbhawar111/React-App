import React from 'react'

const UserPage = () => {
  return (
    <div>UserPage - Accessible to USER</div>
  )
}

export default UserPage