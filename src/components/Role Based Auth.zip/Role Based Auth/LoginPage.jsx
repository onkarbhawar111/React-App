import React from 'react'

const LoginPage = () => {
  return (
    <div>LoginPage - Accessible to Everyone</div>
  )
}

export default LoginPage