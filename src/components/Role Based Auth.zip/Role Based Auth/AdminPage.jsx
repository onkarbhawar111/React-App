import React from 'react'

const AdminPage = () => {
  return (
    <div>AdminPage - Accessible only to ADMIN</div>
  )
}

export default AdminPage