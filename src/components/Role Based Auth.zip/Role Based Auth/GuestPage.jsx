import React from 'react'

const GuestPage = () => {
  return (
    <div>GuestPage - Accessible to Everyone</div>
  )
}

export default GuestPage