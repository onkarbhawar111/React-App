import React from 'react'

const UnAuthorized = () => {
  return (
    <div>UnAuthorized - Accessible to Everyone</div>
  )
}

export default UnAuthorized